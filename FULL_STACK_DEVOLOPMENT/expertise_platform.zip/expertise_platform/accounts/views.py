from django.shortcuts import render, redirect
from staff.models import Staff
from django.http import HttpResponse
from django.contrib import messages
from institutions.models import Institution

def staff_registration(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        staff_id = request.POST.get('staff_id')
        domain_of_study = request.POST.get('domain_of_study')
        years_of_experience = request.POST.get('years_of_experience')
        contact_details = request.POST.get('contact_details')
        current_project = request.POST.get('current_project')
        qualification = request.POST.get('qualification')
        password = request.POST.get('password')

        staff = Staff(
            name=name,
            staff_id=staff_id,
            domain_of_study=domain_of_study,
            years_of_experience=years_of_experience,
            contact_details=contact_details,
            current_project=current_project,
            qualification=qualification,
            password=password
        )
        staff.save()

    return render(request, 'accounts/staff_registration.html')

def staff_login(request):
    if request.method == 'POST':
        userId = request.POST.get('userId')
        password = request.POST.get('password')

        staff = Staff.objects.get(staff_id=userId)
            # Verify the password
        if staff.password == password:
                # Redirect to a specific URL on successful login
            institutions = Institution.objects.all()
            return render(request,'institutions/institution_list.html',{'autheticate':True,'user_name':staff.name,'institutions': institutions})  # Replace 'success_page' with your desired URL nam
        else :
            return HttpResponse("<h1>USER NOT FOUND<h1>")
    return render(request, 'accounts/staff_login.html')

def staff_or_ins(request):
    return render(request, 'accounts/staff_or_ins.html')

def ins_login(request):
    if request.method == 'POST':
        ins_id = request.POST.get('ins_id')
        password = request.POST.get('password')
        institution = Institution.objects.get(institution_id=ins_id)

        if institution.password == password:
            staff = Staff.objects.all()
            return render(request,'staff/staff_list.html',{'autheticate':True,'staff': staff,'institution_name':institution.name,'ins_id':institution.pk})  # Replace with your institution dashboard URL name

    return render(request,'accounts/ins_login.html')

def ins_registor(request):
    if request.method == 'POST':
        id = request.POST.get('id')
        name = request.POST.get('name')
        location = request.POST.get('location')
        contact_info = request.POST.get('contact_info')
        description = request.POST.get('description')
        password = request.POST.get('password')
        
        # Create a new institution and save it
        institution = Institution(
            institution_id = id,
            name=name,
            location=location,
            contact_info=contact_info,
            description=description,
            password=password  # Hash password before saving
        )
        institution.save()
        return redirect('ins_login')
    return render(request,'accounts/ins_register.html')