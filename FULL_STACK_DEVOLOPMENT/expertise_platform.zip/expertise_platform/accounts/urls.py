from django.urls import path
from . import views

urlpatterns = [
    path('staff_register/', views.staff_registration, name='staff_registration'),
    path('staff_login/',views.staff_login,name='staff_login'),
    path('staff_or_ins/',views.staff_or_ins,name='staff_or_ins'),
    path('ins_login/',views.ins_login,name='ins_login'),
    path('ins_reg/',views.ins_registor,name='ins_reg'),
]
