# staff/models.py
from django.db import models

class Staff(models.Model):
    name = models.CharField(max_length=255,null=True)
    staff_id = models.CharField(max_length=25,unique=True,null=True)
    domain_of_study = models.CharField(max_length=255,null=True)
    years_of_experience = models.IntegerField(null=True)
    contact_details = models.CharField(max_length=255,null=True)
    # certifications = models.JSONField()  # Assuming certifications are stored as JSON
    current_project = models.CharField(max_length=255, blank=True, null=True)
    age = models.IntegerField(null=True)
    qualification = models.CharField(max_length=100,null=True)
    address = models.TextField(null=True)
    skills = models.TextField(null=True)
    password = models.CharField(max_length=255,null=True)

    def __str__(self):
        return self.name
