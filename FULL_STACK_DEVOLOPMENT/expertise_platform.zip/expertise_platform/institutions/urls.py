# institutions/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.institution_list, name='institution_list'),
    path('<int:pk>/', views.institution_profile, name='institution_profile'),
    path('<int:pk>/post-requirement/', views.post_requirement, name='post_requirement'),
    path('<int:pk>/ins_staff_view/', views.staff_ins_view, name='ins_staff_view'),
     path('apply-requirement/<int:requirement_id>/', views.apply_requirement, name='apply_requirement'),
     path('institution/<int:pk>/requirements/', views.institution_requirements, name='institution_requirements'),
]
