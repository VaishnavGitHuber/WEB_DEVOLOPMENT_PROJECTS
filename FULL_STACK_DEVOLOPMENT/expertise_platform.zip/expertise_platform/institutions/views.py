from django.shortcuts import render, get_object_or_404,redirect
from .models import Institution, Requirement
from staff.models import Staff
from institutions.models import Application


def institution_list(request):
    query = request.GET.get('q')
    if query:
        institutions = Institution.objects.filter(name__icontains=query)
    else:
        institutions = Institution.objects.all()

    return render(request, 'institutions/institution_list.html', {'institutions': institutions})


def institution_profile(request, pk):
    institution = get_object_or_404(Institution, pk=pk)
    requirements = institution.requirements.all()
    return render(request, 'institutions/institution_profile.html', {'institution': institution, 'requirements': requirements})

def post_requirement(request, pk):
    institution = get_object_or_404(Institution, pk=pk)
    if request.method == 'POST':
        description = request.POST['description']
        Requirement.objects.create(institution=institution, description=description)
        return redirect('institution_profile', pk=institution.pk)
    return render(request, 'institutions/post_requirement.html', {'institution': institution})

def staff_ins_view(request,pk):
    institution = get_object_or_404(Institution, pk=pk)
    requirements = institution.requirements.all()
    return render(request, 'institutions/institution_staff_view.html', {'institution': institution, 'requirements': requirements})

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required


def apply_for_request(request, requirement_id):
    requirement = get_object_or_404(Requirement, id=requirement_id)
    staff = request.user  

    # Create an application entry
    Application.objects.create(requirement=requirement, staff=staff)

    return redirect('institution_detail', institution_id=requirement.institution.id)

def apply_requirement(request, requirement_id):
    if request.method == 'POST':
        staff_id = request.POST.get('staff_id')
        requirement = get_object_or_404(Requirement, id=requirement_id)
        staff = get_object_or_404(Staff, staff_id=staff_id)

        # Create and save the application
        Application.objects.create(requirement=requirement, staff=staff)
    return render(request,'institutions/sucess_page.html')


def institution_requirements(request, pk):
    # Get the institution by primary key
    institution = get_object_or_404(Institution, pk=pk)
    
    # Get all requirements related to this institution
    requirements = Requirement.objects.filter(institution=institution)
    
    # Get all applications for these requirements
    applications = Application.objects.filter(requirement__in=requirements).select_related('staff', 'requirement')
    
    # Pass data to the template
    return render(request, 'institutions/institution_requirements.html', {
        'institution': institution,
        'requirements': requirements,
        'applications': applications
    })