# How to Run the Expertise Sharing Platform

## 1. Prerequisites

Before you begin, ensure you have the following installed on your machine:

- **Python 3.x**: The project is built using Python, so make sure Python 3.x is installed.
- **pip**: Python package installer.
- **Virtualenv**: A tool to create isolated Python environments.
 **sqlviewer**: go tio the extensions section and add it by searching SQLlite Viewer for reference the image of the extension is in the image folder.

## 2. Setting Up Your Environment

1. **Create a Virtual Environment**

   - First, create a folder for your project (e.g., `project`).
   - Add the `expertise_platform` folder to this new `project` folder.
   - Open the `project` folder in VS Code.

2. **Set Up the Environment**

   - Open the terminal in VS Code and type:
     ```bash
     python3 -m venv demo
     ```
   - Once the environment is created, activate it by typing:
     ```bash
     source demo/bin/activate
     ```
     You should see `(demo)` in your terminal, indicating you are in the environment.

3. **Install Requirements**

   - Install the necessary packages by typing:
     ```bash
     pip3 install django
     ```

4. **Run the Server**

   - Navigate to the `expertise_platform` folder:
     ```bash
     cd expertise_platform
     ```
   - Run the server by typing:
     ```bash
     python3 manage.py runserver
     ```
   - You should see the server running in your terminal. Access the platform by typing `http://127.0.0.1:8000` in your browser or hold `Command`/`Ctrl` and click on it to open.

5. **Using the Platform**

   - You can now create users, add expertise, and share it with others. You can also view expertise shared by others.

6. **Access the Django Admin Panel**

   - To make admin changes and view tasks performed on your server, access:
     ```http
     http://127.0.0.1:8000/admin
     ```
   - Admin username: `admin12`
   - Password: `login1234`

   Once in the admin panel, you can view tasks and make changes.

7. **Stopping the Server**

   - To stop the server, type `Ctrl+C` in the terminal in VS Code.

8. **Deactivate the Environment**

   - After stopping the server, deactivate the environment by typing:
     ```bash
     deactivate
     ```
   - You will see the prompt return to normal.

